# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


```python
import pandas as pd
df = pd.read_csv('../input/amazon-top-50-bestselling-books-2009-2019/bestsellers with categories.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-Day Green Smoothie Cleanse</td>
      <td>JJ Smith</td>
      <td>4.7</td>
      <td>17350</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>1</th>
      <td>11/22/63: A Novel</td>
      <td>Stephen King</td>
      <td>4.6</td>
      <td>2052</td>
      <td>22</td>
      <td>2011</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12 Rules for Life: An Antidote to Chaos</td>
      <td>Jordan B. Peterson</td>
      <td>4.7</td>
      <td>18979</td>
      <td>15</td>
      <td>2018</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1984 (Signet Classics)</td>
      <td>George Orwell</td>
      <td>4.7</td>
      <td>21424</td>
      <td>6</td>
      <td>2017</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5,000 Awesome Facts (About Everything!) (Natio...</td>
      <td>National Geographic Kids</td>
      <td>4.8</td>
      <td>7665</td>
      <td>12</td>
      <td>2019</td>
      <td>Non Fiction</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('Year').count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Genre</th>
    </tr>
    <tr>
      <th>Year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2009</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2010</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2011</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2012</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2013</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2014</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2015</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2016</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2017</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2018</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
    <tr>
      <th>2019</th>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
      <td>50</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('Genre').count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
    </tr>
    <tr>
      <th>Genre</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Fiction</th>
      <td>240</td>
      <td>240</td>
      <td>240</td>
      <td>240</td>
      <td>240</td>
      <td>240</td>
    </tr>
    <tr>
      <th>Non Fiction</th>
      <td>310</td>
      <td>310</td>
      <td>310</td>
      <td>310</td>
      <td>310</td>
      <td>310</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('There are more Non-Fiction books in the top list as compared to fiction books for the period of 2009 to 2019')
```

    There are more Non-Fiction books in the top list as compared to fiction books for the period of 2009 to 2019
    


```python
import matplotlib.pyplot as plt
x = ['Fiction', 'Non Fiction']
y = [240,310]
plt.bar(x,y)
```




    <BarContainer object of 2 artists>




    
![png](output_6_1.png)
    



```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>550.000000</td>
      <td>550.000000</td>
      <td>550.000000</td>
      <td>550.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>4.618364</td>
      <td>11953.281818</td>
      <td>13.100000</td>
      <td>2014.000000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.226980</td>
      <td>11731.132017</td>
      <td>10.842262</td>
      <td>3.165156</td>
    </tr>
    <tr>
      <th>min</th>
      <td>3.300000</td>
      <td>37.000000</td>
      <td>0.000000</td>
      <td>2009.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>4.500000</td>
      <td>4058.000000</td>
      <td>7.000000</td>
      <td>2011.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.700000</td>
      <td>8580.000000</td>
      <td>11.000000</td>
      <td>2014.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>4.800000</td>
      <td>17253.250000</td>
      <td>16.000000</td>
      <td>2017.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.900000</td>
      <td>87841.000000</td>
      <td>105.000000</td>
      <td>2019.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.loc[df['Price'] == 105]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>69</th>
      <td>Diagnostic and Statistical Manual of Mental Di...</td>
      <td>American Psychiatric Association</td>
      <td>4.5</td>
      <td>6679</td>
      <td>105</td>
      <td>2013</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>70</th>
      <td>Diagnostic and Statistical Manual of Mental Di...</td>
      <td>American Psychiatric Association</td>
      <td>4.5</td>
      <td>6679</td>
      <td>105</td>
      <td>2014</td>
      <td>Non Fiction</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('Diagnostic and Statistical Manual of Mental Disorders, 5th Edition: DSM-5 is the most expensive book of the decade')
```

    Diagnostic and Statistical Manual of Mental Disorders, 5th Edition: DSM-5 is the most expensive book of the decade
    


```python
df.loc[df['Price'] == 0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>42</th>
      <td>Cabin Fever (Diary of a Wimpy Kid, Book 6)</td>
      <td>Jeff Kinney</td>
      <td>4.8</td>
      <td>4505</td>
      <td>0</td>
      <td>2011</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Diary of a Wimpy Kid: Hard Luck, Book 8</td>
      <td>Jeff Kinney</td>
      <td>4.8</td>
      <td>6812</td>
      <td>0</td>
      <td>2013</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>116</th>
      <td>Frozen (Little Golden Book)</td>
      <td>RH Disney</td>
      <td>4.7</td>
      <td>3642</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>193</th>
      <td>JOURNEY TO THE ICE P</td>
      <td>RH Disney</td>
      <td>4.6</td>
      <td>978</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>219</th>
      <td>Little Blue Truck</td>
      <td>Alice Schertle</td>
      <td>4.9</td>
      <td>1884</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>358</th>
      <td>The Constitution of the United States</td>
      <td>Delegates of the Constitutional</td>
      <td>4.8</td>
      <td>2774</td>
      <td>0</td>
      <td>2016</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>381</th>
      <td>The Getaway</td>
      <td>Jeff Kinney</td>
      <td>4.8</td>
      <td>5836</td>
      <td>0</td>
      <td>2017</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>461</th>
      <td>The Short Second Life of Bree Tanner: An Eclip...</td>
      <td>Stephenie Meyer</td>
      <td>4.6</td>
      <td>2122</td>
      <td>0</td>
      <td>2010</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>505</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2013</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>506</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>507</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2015</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>508</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2016</td>
      <td>Fiction</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('The only Non-ficition book which is available for free is The Constitution of the United States\nOut of all the free books on Fiction the most popular is To Kill a Mockingbird by Harper Lee')
```

    The only Non-ficition book which is available for free is The Constitution of the United States
    Out of all the free books on Fiction the most popular is To Kill a Mockingbird by Harper Lee
    


```python
df_popular = df.loc[df['Reviews'] > 3000]
df_popular
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-Day Green Smoothie Cleanse</td>
      <td>JJ Smith</td>
      <td>4.7</td>
      <td>17350</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12 Rules for Life: An Antidote to Chaos</td>
      <td>Jordan B. Peterson</td>
      <td>4.7</td>
      <td>18979</td>
      <td>15</td>
      <td>2018</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1984 (Signet Classics)</td>
      <td>George Orwell</td>
      <td>4.7</td>
      <td>21424</td>
      <td>6</td>
      <td>2017</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5,000 Awesome Facts (About Everything!) (Natio...</td>
      <td>National Geographic Kids</td>
      <td>4.8</td>
      <td>7665</td>
      <td>12</td>
      <td>2019</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A Dance with Dragons (A Song of Ice and Fire)</td>
      <td>George R. R. Martin</td>
      <td>4.4</td>
      <td>12643</td>
      <td>11</td>
      <td>2011</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Wrecking Ball (Diary of a Wimpy Kid Book 14)</td>
      <td>Jeff Kinney</td>
      <td>4.9</td>
      <td>9413</td>
      <td>8</td>
      <td>2019</td>
      <td>Fiction</td>
    </tr>
    <tr>
      <th>546</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>547</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2017</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>548</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2018</td>
      <td>Non Fiction</td>
    </tr>
    <tr>
      <th>549</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2019</td>
      <td>Non Fiction</td>
    </tr>
  </tbody>
</table>
<p>464 rows × 7 columns</p>
</div>




```python
Avg_User_Rating = ((df['User Rating'])*(df['Reviews']))/(df['Reviews'] + (df['Reviews'].min())) + (df['Reviews'].min()*df['User Rating'].mean())/(df['Reviews'] + df['User Rating'].min())
Avg_User_Rating = Avg_User_Rating
Avg_User_Rating
```




    0      4.699845
    1      4.601666
    2      4.699857
    3      4.699872
    4      4.799225
             ...   
    545    4.898962
    546    4.699818
    547    4.699818
    548    4.699818
    549    4.699818
    Length: 550, dtype: float64




```python
df['Avg_User_Rating'] = Avg_User_Rating
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-Day Green Smoothie Cleanse</td>
      <td>JJ Smith</td>
      <td>4.7</td>
      <td>17350</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.699845</td>
    </tr>
    <tr>
      <th>1</th>
      <td>11/22/63: A Novel</td>
      <td>Stephen King</td>
      <td>4.6</td>
      <td>2052</td>
      <td>22</td>
      <td>2011</td>
      <td>Fiction</td>
      <td>4.601666</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12 Rules for Life: An Antidote to Chaos</td>
      <td>Jordan B. Peterson</td>
      <td>4.7</td>
      <td>18979</td>
      <td>15</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.699857</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1984 (Signet Classics)</td>
      <td>George Orwell</td>
      <td>4.7</td>
      <td>21424</td>
      <td>6</td>
      <td>2017</td>
      <td>Fiction</td>
      <td>4.699872</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5,000 Awesome Facts (About Everything!) (Natio...</td>
      <td>National Geographic Kids</td>
      <td>4.8</td>
      <td>7665</td>
      <td>12</td>
      <td>2019</td>
      <td>Non Fiction</td>
      <td>4.799225</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Wrecking Ball (Diary of a Wimpy Kid Book 14)</td>
      <td>Jeff Kinney</td>
      <td>4.9</td>
      <td>9413</td>
      <td>8</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.898962</td>
    </tr>
    <tr>
      <th>546</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>547</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2017</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>548</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>549</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2019</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
  </tbody>
</table>
<p>550 rows × 8 columns</p>
</div>




```python
df_popular = df.loc[df['Reviews']>3000]
```


```python
df['Avg_User_Rating'].astype(float)
```




    0      4.699845
    1      4.601666
    2      4.699857
    3      4.699872
    4      4.799225
             ...   
    545    4.898962
    546    4.699818
    547    4.699818
    548    4.699818
    549    4.699818
    Name: Avg_User_Rating, Length: 550, dtype: float64




```python
df.drop(df.index[78],inplace=True)
```


```python
df_sorted = df.sort_values(by='Avg_User_Rating',ascending=False)
```


```python
df_popular = df_sorted.loc[df['Reviews']>3000]
df_popular
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>249</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>245</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>246</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>247</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>248</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>392</th>
      <td>The Goldfinch: A Novel (Pulitzer Prize for Fic...</td>
      <td>Donna Tartt</td>
      <td>3.9</td>
      <td>33844</td>
      <td>20</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>3.900790</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Fifty Shades of Grey: Book One of the Fifty Sh...</td>
      <td>E L James</td>
      <td>3.8</td>
      <td>47265</td>
      <td>14</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>3.800643</td>
    </tr>
    <tr>
      <th>107</th>
      <td>Fifty Shades of Grey: Book One of the Fifty Sh...</td>
      <td>E L James</td>
      <td>3.8</td>
      <td>47265</td>
      <td>14</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>3.800643</td>
    </tr>
    <tr>
      <th>132</th>
      <td>Go Set a Watchman: A Novel</td>
      <td>Harper Lee</td>
      <td>3.6</td>
      <td>14982</td>
      <td>19</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>3.602534</td>
    </tr>
    <tr>
      <th>353</th>
      <td>The Casual Vacancy</td>
      <td>J.K. Rowling</td>
      <td>3.3</td>
      <td>9372</td>
      <td>12</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>3.305250</td>
    </tr>
  </tbody>
</table>
<p>464 rows × 8 columns</p>
</div>




```python
df_popular_without_duplicates = df_popular.drop_duplicates('Name')
df_popular_without_duplicates
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>249</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>153</th>
      <td>Harry Potter and the Chamber of Secrets: The I...</td>
      <td>J.K. Rowling</td>
      <td>4.9</td>
      <td>19622</td>
      <td>30</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899485</td>
    </tr>
    <tr>
      <th>190</th>
      <td>Jesus Calling: Enjoying Peace in His Presence ...</td>
      <td>Sarah Young</td>
      <td>4.9</td>
      <td>19576</td>
      <td>8</td>
      <td>2014</td>
      <td>Non Fiction</td>
      <td>4.899484</td>
    </tr>
    <tr>
      <th>481</th>
      <td>The Very Hungry Caterpillar</td>
      <td>Eric Carle</td>
      <td>4.9</td>
      <td>19546</td>
      <td>5</td>
      <td>2018</td>
      <td>Fiction</td>
      <td>4.899483</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Brown Bear, Brown Bear, What Do You See?</td>
      <td>Bill Martin Jr.</td>
      <td>4.9</td>
      <td>14344</td>
      <td>5</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.899303</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Allegiant</td>
      <td>Veronica Roth</td>
      <td>3.9</td>
      <td>6310</td>
      <td>13</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>3.904331</td>
    </tr>
    <tr>
      <th>393</th>
      <td>The Goldfinch: A Novel (Pulitzer Prize for Fic...</td>
      <td>Donna Tartt</td>
      <td>3.9</td>
      <td>33844</td>
      <td>20</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>3.900790</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Fifty Shades of Grey: Book One of the Fifty Sh...</td>
      <td>E L James</td>
      <td>3.8</td>
      <td>47265</td>
      <td>14</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>3.800643</td>
    </tr>
    <tr>
      <th>132</th>
      <td>Go Set a Watchman: A Novel</td>
      <td>Harper Lee</td>
      <td>3.6</td>
      <td>14982</td>
      <td>19</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>3.602534</td>
    </tr>
    <tr>
      <th>353</th>
      <td>The Casual Vacancy</td>
      <td>J.K. Rowling</td>
      <td>3.3</td>
      <td>9372</td>
      <td>12</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>3.305250</td>
    </tr>
  </tbody>
</table>
<p>273 rows × 8 columns</p>
</div>




```python
df_Top_10 = df_popular_without_duplicates.head(10)
df_Top_10
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>249</th>
      <td>Oh, the Places You'll Go!</td>
      <td>Dr. Seuss</td>
      <td>4.9</td>
      <td>21834</td>
      <td>8</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899536</td>
    </tr>
    <tr>
      <th>153</th>
      <td>Harry Potter and the Chamber of Secrets: The I...</td>
      <td>J.K. Rowling</td>
      <td>4.9</td>
      <td>19622</td>
      <td>30</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899485</td>
    </tr>
    <tr>
      <th>190</th>
      <td>Jesus Calling: Enjoying Peace in His Presence ...</td>
      <td>Sarah Young</td>
      <td>4.9</td>
      <td>19576</td>
      <td>8</td>
      <td>2014</td>
      <td>Non Fiction</td>
      <td>4.899484</td>
    </tr>
    <tr>
      <th>481</th>
      <td>The Very Hungry Caterpillar</td>
      <td>Eric Carle</td>
      <td>4.9</td>
      <td>19546</td>
      <td>5</td>
      <td>2018</td>
      <td>Fiction</td>
      <td>4.899483</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Brown Bear, Brown Bear, What Do You See?</td>
      <td>Bill Martin Jr.</td>
      <td>4.9</td>
      <td>14344</td>
      <td>5</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.899303</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Dog Man: Fetch-22: From the Creator of Captain...</td>
      <td>Dav Pilkey</td>
      <td>4.9</td>
      <td>12619</td>
      <td>8</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.899213</td>
    </tr>
    <tr>
      <th>207</th>
      <td>Last Week Tonight with John Oliver Presents A ...</td>
      <td>Jill Twiss</td>
      <td>4.9</td>
      <td>11881</td>
      <td>13</td>
      <td>2018</td>
      <td>Fiction</td>
      <td>4.899166</td>
    </tr>
    <tr>
      <th>157</th>
      <td>Harry Potter and the Sorcerer's Stone: The Ill...</td>
      <td>J.K. Rowling</td>
      <td>4.9</td>
      <td>10052</td>
      <td>22</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.899024</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Wrecking Ball (Diary of a Wimpy Kid Book 14)</td>
      <td>Jeff Kinney</td>
      <td>4.9</td>
      <td>9413</td>
      <td>8</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.898962</td>
    </tr>
    <tr>
      <th>303</th>
      <td>Strange Planet (Strange Planet Series)</td>
      <td>Nathan W. Pyle</td>
      <td>4.9</td>
      <td>9382</td>
      <td>6</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.898959</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('People prefer Fiction books over Non-Fiction in recent years')
```

    People prefer Fiction books over Non-Fiction in recent years
    


```python
x = df_Top_10['Author']
y = df_Top_10['Reviews']
import matplotlib.pyplot as plt
plt.bar(x,y)
plt.xticks(rotation = 90)
```




    ([0, 1, 2, 3, 4, 5, 6, 7, 8], <a list of 9 Text major ticklabel objects>)




    
![png](output_24_1.png)
    



```python
print('The most popular author in the top avg rated list is Dr. Seuss with his best selling fiction book:  Oh,the Places You\'ll Go!')
```

    The most popular author in the top avg rated list is Dr. Seuss with his best selling fiction book:  Oh,the Places You'll Go!
    


```python
x = df_Top_10['Name']
y = df_Top_10['Reviews']
import matplotlib.pyplot as plt
plt.bar(x,y)
plt.xticks(rotation = 90)
```




    ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], <a list of 10 Text major ticklabel objects>)



    /opt/conda/lib/python3.7/site-packages/matplotlib/backends/backend_agg.py:214: RuntimeWarning: Glyph 146 missing from current font.
      font.set_text(s, 0.0, flags=flags)
    /opt/conda/lib/python3.7/site-packages/matplotlib/backends/backend_agg.py:183: RuntimeWarning: Glyph 146 missing from current font.
      font.set_text(s, 0, flags=flags)
    


    
![png](output_26_2.png)
    



```python
x = df_Top_10['Name']
y = df_Top_10['Price']
import matplotlib.pyplot as plt
plt.bar(x,y)
plt.xticks(rotation = 90)
plt.title('Top 10 books distributed by Price')
plt.ylabel('Price')
plt.xlabel('Name')
```




    Text(0.5, 0, 'Name')




    
![png](output_27_1.png)
    



```python
x = df_Top_10['Author']
y = df_Top_10['Price']
import matplotlib.pyplot as plt
plt.bar(x,y)
plt.xticks(rotation = 90)
plt.title('Top 10 Authors distributed by Price')
plt.ylabel('Price')
plt.xlabel('Author')
```




    Text(0.5, 0, 'Author')




    
![png](output_28_1.png)
    



```python
print('Hence it can be seen that books written by JK Rowling are most expensive from the top avg rated list while Eric Carle and Bill Martin Jr. are authors whose books are least expensive')
```

    Hence it can be seen that books written by JK Rowling are most expensive from the top avg rated list while Eric Carle and Bill Martin Jr. are authors whose books are least expensive
    


```python
df_costliest_books = df.sort_values(by='Price',ascending=False)
df_costliest_books
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>70</th>
      <td>Diagnostic and Statistical Manual of Mental Di...</td>
      <td>American Psychiatric Association</td>
      <td>4.5</td>
      <td>6679</td>
      <td>105</td>
      <td>2014</td>
      <td>Non Fiction</td>
      <td>4.500780</td>
    </tr>
    <tr>
      <th>69</th>
      <td>Diagnostic and Statistical Manual of Mental Di...</td>
      <td>American Psychiatric Association</td>
      <td>4.5</td>
      <td>6679</td>
      <td>105</td>
      <td>2013</td>
      <td>Non Fiction</td>
      <td>4.500780</td>
    </tr>
    <tr>
      <th>473</th>
      <td>The Twilight Saga Collection</td>
      <td>Stephenie Meyer</td>
      <td>4.7</td>
      <td>3801</td>
      <td>82</td>
      <td>2009</td>
      <td>Fiction</td>
      <td>4.699607</td>
    </tr>
    <tr>
      <th>151</th>
      <td>Hamilton: The Revolution</td>
      <td>Lin-Manuel Miranda</td>
      <td>4.9</td>
      <td>5867</td>
      <td>54</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.898401</td>
    </tr>
    <tr>
      <th>346</th>
      <td>The Book of Basketball: The NBA According to T...</td>
      <td>Bill Simmons</td>
      <td>4.7</td>
      <td>858</td>
      <td>53</td>
      <td>2009</td>
      <td>Non Fiction</td>
      <td>4.704095</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>116</th>
      <td>Frozen (Little Golden Book)</td>
      <td>RH Disney</td>
      <td>4.7</td>
      <td>3642</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.699608</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Diary of a Wimpy Kid: Hard Luck, Book 8</td>
      <td>Jeff Kinney</td>
      <td>4.8</td>
      <td>6812</td>
      <td>0</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>4.799142</td>
    </tr>
    <tr>
      <th>505</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2013</td>
      <td>Fiction</td>
      <td>4.799753</td>
    </tr>
    <tr>
      <th>506</th>
      <td>To Kill a Mockingbird</td>
      <td>Harper Lee</td>
      <td>4.8</td>
      <td>26234</td>
      <td>0</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.799753</td>
    </tr>
    <tr>
      <th>358</th>
      <td>The Constitution of the United States</td>
      <td>Delegates of the Constitutional</td>
      <td>4.8</td>
      <td>2774</td>
      <td>0</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.798347</td>
    </tr>
  </tbody>
</table>
<p>549 rows × 8 columns</p>
</div>




```python
df_top_10_costliest_books = df_costliest_books.drop_duplicates('Price').head(10)
df_top_10_costliest_books
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>70</th>
      <td>Diagnostic and Statistical Manual of Mental Di...</td>
      <td>American Psychiatric Association</td>
      <td>4.5</td>
      <td>6679</td>
      <td>105</td>
      <td>2014</td>
      <td>Non Fiction</td>
      <td>4.500780</td>
    </tr>
    <tr>
      <th>473</th>
      <td>The Twilight Saga Collection</td>
      <td>Stephenie Meyer</td>
      <td>4.7</td>
      <td>3801</td>
      <td>82</td>
      <td>2009</td>
      <td>Fiction</td>
      <td>4.699607</td>
    </tr>
    <tr>
      <th>151</th>
      <td>Hamilton: The Revolution</td>
      <td>Lin-Manuel Miranda</td>
      <td>4.9</td>
      <td>5867</td>
      <td>54</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.898401</td>
    </tr>
    <tr>
      <th>346</th>
      <td>The Book of Basketball: The NBA According to T...</td>
      <td>Bill Simmons</td>
      <td>4.7</td>
      <td>858</td>
      <td>53</td>
      <td>2009</td>
      <td>Non Fiction</td>
      <td>4.704095</td>
    </tr>
    <tr>
      <th>159</th>
      <td>Harry Potter Paperback Box Set (Books 1-7)</td>
      <td>J. K. Rowling</td>
      <td>4.8</td>
      <td>13471</td>
      <td>52</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.799534</td>
    </tr>
    <tr>
      <th>280</th>
      <td>Publication Manual of the American Psychologic...</td>
      <td>American Psychological Association</td>
      <td>4.5</td>
      <td>8580</td>
      <td>46</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.500586</td>
    </tr>
    <tr>
      <th>524</th>
      <td>Watchmen</td>
      <td>Alan Moore</td>
      <td>4.8</td>
      <td>3829</td>
      <td>42</td>
      <td>2009</td>
      <td>Fiction</td>
      <td>4.798650</td>
    </tr>
    <tr>
      <th>442</th>
      <td>The Official SAT Study Guide</td>
      <td>The College Board</td>
      <td>4.4</td>
      <td>1201</td>
      <td>40</td>
      <td>2013</td>
      <td>Non Fiction</td>
      <td>4.410389</td>
    </tr>
    <tr>
      <th>338</th>
      <td>The Alchemist</td>
      <td>Paulo Coelho</td>
      <td>4.7</td>
      <td>35799</td>
      <td>39</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.699920</td>
    </tr>
    <tr>
      <th>444</th>
      <td>The Official SAT Study Guide, 2016 Edition (Of...</td>
      <td>The College Board</td>
      <td>4.3</td>
      <td>807</td>
      <td>36</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.322377</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
x = df_top_10_costliest_books['Name']
y = df_top_10_costliest_books['Price']
plt.bar(x,y)
plt.title('Costliest Books')
plt.xticks(rotation = 90)
plt.xlabel('Name')
plt.ylabel('Price')
plt.show()
```


    
![png](output_32_0.png)
    



```python
print('Diagnostic and Statistical Manual of Mental Disorders is the most expensive book. A book by American Psychiatric Asso. due to its multiple pages is the most expensive in the list')
```

    Diagnostic and Statistical Manual of Mental Disorders is the most expensive book. A book by American Psychiatric Asso. due to its multiple pages is the most expensive in the list
    


```python
import matplotlib.pyplot as plt
x = df_top_10_costliest_books['Author']
y = df_top_10_costliest_books['Price']
plt.bar(x,y)
plt.title('Authors of Costliest Books')
plt.xticks(rotation = 90)
plt.xlabel('Author')
plt.ylabel('Price')
plt.show()
```


    
![png](output_34_0.png)
    



```python
df.groupby(['Genre'])['Price'].mean()
```




    Genre
    Fiction        10.85000
    Non Fiction    14.87055
    Name: Price, dtype: float64




```python
print('On an average Non Fiction books cost more the Fiction books because various educational texts,history books fall under Non Fictional category')
```

    On an average Non Fiction books cost more the Fiction books because various educational texts,history books fall under Non Fictional category
    


```python
df_top_reviewed_books = df.sort_values(by='Reviews',ascending=False)
df_top_reviewed_books
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>534</th>
      <td>Where the Crawdads Sing</td>
      <td>Delia Owens</td>
      <td>4.8</td>
      <td>87841</td>
      <td>15</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.799924</td>
    </tr>
    <tr>
      <th>382</th>
      <td>The Girl on the Train</td>
      <td>Paula Hawkins</td>
      <td>4.1</td>
      <td>79446</td>
      <td>18</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.100242</td>
    </tr>
    <tr>
      <th>383</th>
      <td>The Girl on the Train</td>
      <td>Paula Hawkins</td>
      <td>4.1</td>
      <td>79446</td>
      <td>7</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.100242</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Becoming</td>
      <td>Michelle Obama</td>
      <td>4.8</td>
      <td>61133</td>
      <td>11</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.799892</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Becoming</td>
      <td>Michelle Obama</td>
      <td>4.8</td>
      <td>61133</td>
      <td>11</td>
      <td>2019</td>
      <td>Non Fiction</td>
      <td>4.799892</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11</th>
      <td>A Patriot's History of the United States: From...</td>
      <td>Larry Schweikart</td>
      <td>4.6</td>
      <td>460</td>
      <td>2</td>
      <td>2010</td>
      <td>Non Fiction</td>
      <td>4.626376</td>
    </tr>
    <tr>
      <th>359</th>
      <td>The Daily Show with Jon Stewart Presents Earth...</td>
      <td>Jon Stewart</td>
      <td>4.4</td>
      <td>440</td>
      <td>11</td>
      <td>2010</td>
      <td>Non Fiction</td>
      <td>4.444172</td>
    </tr>
    <tr>
      <th>512</th>
      <td>True Compass: A Memoir</td>
      <td>Edward M. Kennedy</td>
      <td>4.5</td>
      <td>438</td>
      <td>15</td>
      <td>2009</td>
      <td>Non Fiction</td>
      <td>4.536692</td>
    </tr>
    <tr>
      <th>121</th>
      <td>George Washington's Sacred Fire</td>
      <td>Peter A. Lillback</td>
      <td>4.5</td>
      <td>408</td>
      <td>20</td>
      <td>2010</td>
      <td>Non Fiction</td>
      <td>4.541305</td>
    </tr>
    <tr>
      <th>300</th>
      <td>Soul Healing Miracles: Ancient and New Sacred ...</td>
      <td>Zhi Gang Sha</td>
      <td>4.6</td>
      <td>220</td>
      <td>17</td>
      <td>2013</td>
      <td>Non Fiction</td>
      <td>4.702989</td>
    </tr>
  </tbody>
</table>
<p>549 rows × 8 columns</p>
</div>




```python
df_top_reviewed_books_without_duplicates = df_top_reviewed_books.drop_duplicates('Reviews')
df_top_reviewed_books_without_duplicates.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>534</th>
      <td>Where the Crawdads Sing</td>
      <td>Delia Owens</td>
      <td>4.8</td>
      <td>87841</td>
      <td>15</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.799924</td>
    </tr>
    <tr>
      <th>382</th>
      <td>The Girl on the Train</td>
      <td>Paula Hawkins</td>
      <td>4.1</td>
      <td>79446</td>
      <td>18</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.100242</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Becoming</td>
      <td>Michelle Obama</td>
      <td>4.8</td>
      <td>61133</td>
      <td>11</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.799892</td>
    </tr>
    <tr>
      <th>137</th>
      <td>Gone Girl</td>
      <td>Gillian Flynn</td>
      <td>4.0</td>
      <td>57271</td>
      <td>9</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.000401</td>
    </tr>
    <tr>
      <th>368</th>
      <td>The Fault in Our Stars</td>
      <td>John Green</td>
      <td>4.7</td>
      <td>50482</td>
      <td>13</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.699942</td>
    </tr>
    <tr>
      <th>437</th>
      <td>The Nightingale: A Novel</td>
      <td>Kristin Hannah</td>
      <td>4.8</td>
      <td>49288</td>
      <td>11</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.799866</td>
    </tr>
    <tr>
      <th>106</th>
      <td>Fifty Shades of Grey: Book One of the Fifty Sh...</td>
      <td>E L James</td>
      <td>3.8</td>
      <td>47265</td>
      <td>14</td>
      <td>2012</td>
      <td>Fiction</td>
      <td>3.800643</td>
    </tr>
    <tr>
      <th>433</th>
      <td>The Martian</td>
      <td>Andy Weir</td>
      <td>4.7</td>
      <td>39459</td>
      <td>9</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.699927</td>
    </tr>
    <tr>
      <th>20</th>
      <td>All the Light We Cannot See</td>
      <td>Anthony Doerr</td>
      <td>4.6</td>
      <td>36348</td>
      <td>14</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.600023</td>
    </tr>
    <tr>
      <th>338</th>
      <td>The Alchemist</td>
      <td>Paulo Coelho</td>
      <td>4.7</td>
      <td>35799</td>
      <td>39</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.699920</td>
    </tr>
  </tbody>
</table>
</div>




```python
print('9 out of 10 books are of Fiction which are most reviewed, while the only Non-Fiction book that is most reviewed is Becoming by Michelle Obama')
```

    9 out of 10 books are of Fiction which are most reviewed, while the only Non-Fiction book that is most reviewed is Becoming by Michelle Obama
    


```python
import matplotlib.pyplot as plt
x = df_top_reviewed_books_without_duplicates.head(10)['Name']
y = df_top_reviewed_books_without_duplicates.head(10)['Reviews']
plt.bar(x,y)
plt.title('Most reviewed Books')
plt.xticks(rotation = 90)
plt.xlabel('Name')
plt.ylabel('Reviews')
plt.show()
```


    
![png](output_40_0.png)
    



```python
import matplotlib.pyplot as plt
x = df_top_reviewed_books_without_duplicates.head(10)['Name']
y = df_top_reviewed_books_without_duplicates.head(10)['Avg_User_Rating']
plt.bar(x,y)
plt.title('Most reviewed Books as per the avg rating ')
plt.xticks(rotation = 90)
plt.xlabel('Name')
plt.ylabel('Rating')
plt.show()
```


    
![png](output_41_0.png)
    



```python
import matplotlib.pyplot as plt
x = df_top_reviewed_books_without_duplicates.head(10)['Author']
y = df_top_reviewed_books_without_duplicates.head(10)['Reviews']
plt.bar(x,y)
plt.title('Most reviewed Authors')
plt.xticks(rotation = 90)
plt.xlabel('Author')
plt.ylabel('Reviews')
plt.show()
```


    
![png](output_42_0.png)
    



```python
import matplotlib.pyplot as plt
x = df_top_reviewed_books_without_duplicates.head(10)['Author']
y = df_top_reviewed_books_without_duplicates.head(10)['Price']
plt.bar(x,y)
plt.title('Most reviewed Authors and their books as per price')
plt.xticks(rotation = 90)
plt.xlabel('Author')
plt.ylabel('Price')
plt.show()
```


    
![png](output_43_0.png)
    



```python
df.groupby(['Genre'])['Reviews'].mean()
```




    Genre
    Fiction        15683.791667
    Non Fiction     9094.362460
    Name: Reviews, dtype: float64




```python
print('Fiction reviewers are more aggressive in giving reviews as compared to Non-Ficition one\'s')
```

    Fiction reviewers are more aggressive in giving reviews as compared to Non-Ficition one's
    


```python
df_fiction = df.loc[(df['Genre']=='Fiction')]
df_fiction
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>11/22/63: A Novel</td>
      <td>Stephen King</td>
      <td>4.6</td>
      <td>2052</td>
      <td>22</td>
      <td>2011</td>
      <td>Fiction</td>
      <td>4.601666</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1984 (Signet Classics)</td>
      <td>George Orwell</td>
      <td>4.7</td>
      <td>21424</td>
      <td>6</td>
      <td>2017</td>
      <td>Fiction</td>
      <td>4.699872</td>
    </tr>
    <tr>
      <th>5</th>
      <td>A Dance with Dragons (A Song of Ice and Fire)</td>
      <td>George R. R. Martin</td>
      <td>4.4</td>
      <td>12643</td>
      <td>11</td>
      <td>2011</td>
      <td>Fiction</td>
      <td>4.400673</td>
    </tr>
    <tr>
      <th>6</th>
      <td>A Game of Thrones / A Clash of Kings / A Storm...</td>
      <td>George R. R. Martin</td>
      <td>4.7</td>
      <td>19735</td>
      <td>30</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.699862</td>
    </tr>
    <tr>
      <th>7</th>
      <td>A Gentleman in Moscow: A Novel</td>
      <td>Amor Towles</td>
      <td>4.7</td>
      <td>19699</td>
      <td>15</td>
      <td>2017</td>
      <td>Fiction</td>
      <td>4.699862</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>541</th>
      <td>Wonder</td>
      <td>R. J. Palacio</td>
      <td>4.8</td>
      <td>21625</td>
      <td>9</td>
      <td>2014</td>
      <td>Fiction</td>
      <td>4.799702</td>
    </tr>
    <tr>
      <th>542</th>
      <td>Wonder</td>
      <td>R. J. Palacio</td>
      <td>4.8</td>
      <td>21625</td>
      <td>9</td>
      <td>2015</td>
      <td>Fiction</td>
      <td>4.799702</td>
    </tr>
    <tr>
      <th>543</th>
      <td>Wonder</td>
      <td>R. J. Palacio</td>
      <td>4.8</td>
      <td>21625</td>
      <td>9</td>
      <td>2016</td>
      <td>Fiction</td>
      <td>4.799702</td>
    </tr>
    <tr>
      <th>544</th>
      <td>Wonder</td>
      <td>R. J. Palacio</td>
      <td>4.8</td>
      <td>21625</td>
      <td>9</td>
      <td>2017</td>
      <td>Fiction</td>
      <td>4.799702</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Wrecking Ball (Diary of a Wimpy Kid Book 14)</td>
      <td>Jeff Kinney</td>
      <td>4.9</td>
      <td>9413</td>
      <td>8</td>
      <td>2019</td>
      <td>Fiction</td>
      <td>4.898962</td>
    </tr>
  </tbody>
</table>
<p>240 rows × 8 columns</p>
</div>




```python
df_non_fiction = df.loc[(df['Genre']=='Non Fiction')]
df_non_fiction
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Author</th>
      <th>User Rating</th>
      <th>Reviews</th>
      <th>Price</th>
      <th>Year</th>
      <th>Genre</th>
      <th>Avg_User_Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>10-Day Green Smoothie Cleanse</td>
      <td>JJ Smith</td>
      <td>4.7</td>
      <td>17350</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.699845</td>
    </tr>
    <tr>
      <th>2</th>
      <td>12 Rules for Life: An Antidote to Chaos</td>
      <td>Jordan B. Peterson</td>
      <td>4.7</td>
      <td>18979</td>
      <td>15</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.699857</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5,000 Awesome Facts (About Everything!) (Natio...</td>
      <td>National Geographic Kids</td>
      <td>4.8</td>
      <td>7665</td>
      <td>12</td>
      <td>2019</td>
      <td>Non Fiction</td>
      <td>4.799225</td>
    </tr>
    <tr>
      <th>8</th>
      <td>A Higher Loyalty: Truth, Lies, and Leadership</td>
      <td>James Comey</td>
      <td>4.7</td>
      <td>5983</td>
      <td>3</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.699658</td>
    </tr>
    <tr>
      <th>11</th>
      <td>A Patriot's History of the United States: From...</td>
      <td>Larry Schweikart</td>
      <td>4.6</td>
      <td>460</td>
      <td>2</td>
      <td>2010</td>
      <td>Non Fiction</td>
      <td>4.626376</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>539</th>
      <td>Women Food and God: An Unexpected Path to Almo...</td>
      <td>Geneen Roth</td>
      <td>4.2</td>
      <td>1302</td>
      <td>11</td>
      <td>2010</td>
      <td>Non Fiction</td>
      <td>4.214855</td>
    </tr>
    <tr>
      <th>546</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2016</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>547</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2017</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>548</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2018</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
    <tr>
      <th>549</th>
      <td>You Are a Badass: How to Stop Doubting Your Gr...</td>
      <td>Jen Sincero</td>
      <td>4.7</td>
      <td>14331</td>
      <td>8</td>
      <td>2019</td>
      <td>Non Fiction</td>
      <td>4.699818</td>
    </tr>
  </tbody>
</table>
<p>309 rows × 8 columns</p>
</div>




```python
import matplotlib.pyplot as plt
x = df_fiction['Year']
y = df_fiction['Reviews']
plt.bar(x,y)
plt.title('Trend of reviews of Fiction Books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Reviews')
plt.show()
```


    
![png](output_48_0.png)
    



```python
print('There is a rise in number of reviewers of Fiction Books over the years except a sudden drop in years 2017-2018')
```

    There is a rise in number of reviewers of Fiction Books over the years except a sudden drop in years 2017-2018
    


```python
import matplotlib.pyplot as plt
x = df_non_fiction['Year']
y = df_non_fiction['Reviews']
plt.bar(x,y,color='red')
plt.title('Trend of reviews for Non fiction books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Reviews')
plt.show()
```


    
![png](output_50_0.png)
    



```python
print('There has been a steep rise in reviewers of Non-Fiction books after 2017')
```

    There has been a steep rise in reviewers of Non-Fiction books after 2017
    


```python
import matplotlib.pyplot as plt
x = df_fiction['Year']
y = df_fiction['Price']
plt.bar(x,y)
plt.title('Trend of Price of Fiction books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Price')
plt.show()
```


    
![png](output_52_0.png)
    



```python
print('Over the years there has been an overall downward trend to the price of Fiction books')
```

    Over the years there has been an overall downward trend to the price of Fiction books
    


```python
import matplotlib.pyplot as plt
x = df_non_fiction['Year']
y = df_non_fiction['Price']
plt.bar(x,y,color='red')
plt.title('Trend of Price for Non fiction books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Price')
plt.show()
```


    
![png](output_54_0.png)
    



```python
print('While Non-Ficition books priced the same except for 2013,2014')
```

    While Non-Ficition books priced the same except for 2013,2014
    


```python
import matplotlib.pyplot as plt
x = df_fiction['Year']
y = df_fiction['Avg_User_Rating']
plt.bar(x,y)
plt.title('Trend of Avg Rating of Fiction books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Avg Rating')
plt.show()
```


    
![png](output_56_0.png)
    



```python
import matplotlib.pyplot as plt
x = df_non_fiction['Year']
y = df_non_fiction['Avg_User_Rating']
plt.bar(x,y,color='red')
plt.title('Trend of Avg Rating for Non fiction books over the years ')
plt.xticks(rotation = 90)
plt.xlabel('Year')
plt.ylabel('Avg Rating')
plt.show()
```


    
![png](output_57_0.png)
    



```python
print('Over the years Avg rating for Fiction as well as Non-Fiction books have marginally increased')
```

    Over the years Avg rating for Fiction as well as Non-Fiction books have marginally increased
    


```python
print('Conclusion: It can be concluded that there are more Non-Fiction books in the top list compared to Fiction books. Also Fiction books are less expensive compared to Non-Fiction one\'s.') 
```

    Conclusion: It can be concluded that there are more Non-Fiction books in the top list compared to Fiction books. Also Fiction books are less expensive compared to Non-Fiction one's.
    
